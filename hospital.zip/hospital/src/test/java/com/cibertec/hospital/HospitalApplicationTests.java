package com.cibertec.hospital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
